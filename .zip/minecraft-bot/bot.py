import os
import sys
import time
import logging
from minecraft.networking.connection import Connection
from minecraft.networking.packets import clientbound

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

HOST = os.environ.get("MC_HOST", "")
PORT = int(os.environ.get("MC_PORT", "25565"))
USERNAME = os.environ.get("MC_USERNAME", "KeepAliveBot")
VERSION = os.environ.get("MC_VERSION", "")

RECONNECT_DELAY = 30

VERSIONS_TO_TRY = [
    "1.21.4", "1.21.3", "1.21.1", "1.21",
    "1.20.6", "1.20.4", "1.20.2", "1.20.1",
    "1.19.4", "1.19.2", "1.18.2", "1.17.1",
    "1.16.5", "1.16.4", "1.16.3",
]


def run():
    if not HOST:
        log.error("MC_HOST is not set. Edit the .env file and set your server address.")
        sys.exit(1)

    log.info(f"Bot username : {USERNAME}")
    log.info(f"Target server: {HOST}:{PORT}")

    versions = [VERSION] if VERSION else VERSIONS_TO_TRY

    while True:
        connected = False
        for version in versions:
            log.info(f"Trying version {version}...")
            try:
                connect(version)
                connected = True
                break
            except KeyboardInterrupt:
                log.info("Interrupted — shutting down.")
                sys.exit(0)
            except Exception as exc:
                log.warning(f"[{version}] {exc}")

        if not connected:
            log.warning(f"All versions failed. Retrying in {RECONNECT_DELAY}s...")

        log.info(f"Reconnecting in {RECONNECT_DELAY} seconds...")
        time.sleep(RECONNECT_DELAY)


def connect(version):
    connection = Connection(HOST, PORT, username=USERNAME, initial_version=version)
    connected = [False]

    @connection.listener(clientbound.play.JoinGamePacket)
    def on_join(packet):
        connected[0] = True
        log.info(f"Joined the server on version {version}! (entity id: {packet.entity_id})")

    @connection.listener(clientbound.play.DisconnectPacket)
    def on_disconnect(packet):
        log.warning(f"Disconnected by server: {packet.json_data}")

    @connection.listener(clientbound.login.DisconnectPacket)
    def on_login_disconnect(packet):
        log.error(f"Login rejected: {packet.json_data}")

    connection.connect()

    log.info(f"Waiting for login ({version})...")
    timeout = 15
    elapsed = 0
    while not connected[0] and elapsed < timeout:
        time.sleep(0.5)
        elapsed += 0.5

    if not connected[0]:
        connection.disconnect()
        raise TimeoutError(f"Timed out waiting to join ({version}).")

    log.info("Bot is online. Keeping the server alive...")
    try:
        while connection.connected:
            time.sleep(1)
    finally:
        if connection.connected:
            connection.disconnect()
        log.info("Disconnected.")


if __name__ == "__main__":
    run()
