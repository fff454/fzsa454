# Minecraft Keep-Alive Bot

A simple Python bot that joins a Minecraft server and stays connected to prevent it from shutting down due to inactivity.

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Edit `.env` and set your server details:
   ```
   MC_HOST=your.server.address
   MC_PORT=25565
   MC_USERNAME=KeepAliveBot
   ```

3. Run the bot:
   ```
   MC_HOST=your.server.address MC_PORT=25565 python bot.py
   ```
   Or export the variables from `.env` first.

## Notes

- The bot connects in **offline/cracked mode** (no Microsoft login required).  
  This works on servers with `online-mode=false` in `server.properties`.
- If the connection drops, the bot automatically reconnects after 30 seconds.
- Press `Ctrl+C` to stop the bot.
