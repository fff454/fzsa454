import mineflayer from "mineflayer";
import http from "http";
import { readFileSync, existsSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));

// Load .env file
const envPath = resolve(__dirname, ".env");
if (existsSync(envPath)) {
  for (const line of readFileSync(envPath, "utf8").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIdx = trimmed.indexOf("=");
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    const value = trimmed.slice(eqIdx + 1).trim();
    if (key && !(key in process.env)) process.env[key] = value;
  }
}

const HOST = process.env.MC_HOST || "";
const PORT = parseInt(process.env.MC_PORT || "25565", 10);
const USERNAME = process.env.MC_USERNAME || "KeepAliveBot";
const VERSION = process.env.MC_VERSION || undefined;
const HTTP_PORT = parseInt(process.env.PORT || "3000", 10);

const RECONNECT_DELAY_MS = 5_000;

if (!HOST) {
  console.error("[ERROR] MC_HOST is not set. Edit minecraft-bot/.env first.");
  process.exit(1);
}

const log = (level, msg) =>
  console.log(`${new Date().toISOString().replace("T", " ").slice(0, 19)} [${level}] ${msg}`);

// ── Keep-alive HTTP server ──────────────────────────────────────────────────
// Ping this URL with UptimeRobot every 5 minutes to prevent Replit from sleeping.
let botStatus = "starting";

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/plain" });
  res.end(`Minecraft bot is ${botStatus}\nServer: ${HOST}:${PORT}\n`);
});

server.listen(HTTP_PORT, () => {
  log("INFO", `Keep-alive server listening on port ${HTTP_PORT}`);
});

// ── Minecraft bot ───────────────────────────────────────────────────────────
function connect() {
  log("INFO", `Connecting to ${HOST}:${PORT} as "${USERNAME}"${VERSION ? ` (v${VERSION})` : ""}...`);
  botStatus = "connecting";

  const botOpts = {
    host: HOST,
    port: PORT,
    username: USERNAME,
    auth: "offline",
    hideErrors: true,
  };
  if (VERSION) botOpts.version = VERSION;

  const bot = mineflayer.createBot(botOpts);

  bot.once("spawn", () => {
    botStatus = "online";
    log("INFO", "Connected and keeping the server alive.");
  });

  bot.on("kicked", (reason) => {
    botStatus = "reconnecting";
    log("WARN", `Kicked: ${reason} — reconnecting in ${RECONNECT_DELAY_MS / 1000}s...`);
  });

  bot.on("error", (err) => {
    log("WARN", `Error: ${err.message}`);
  });

  bot.on("end", () => {
    botStatus = "reconnecting";
    log("INFO", `Disconnected — reconnecting in ${RECONNECT_DELAY_MS / 1000}s...`);
    setTimeout(connect, RECONNECT_DELAY_MS);
  });
}

process.on("SIGINT", () => {
  log("INFO", "Shutting down.");
  process.exit(0);
});

connect();
